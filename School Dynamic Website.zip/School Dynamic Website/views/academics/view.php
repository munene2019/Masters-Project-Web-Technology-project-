<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
$this->title = 'academics: '.$model->title;
?>
<section id="services" class="services">
      <div class="container-fluid">

<!-- Basic Card Example -->
<div class="card shadow mb-4">
	<div class="card-header py-3">    
	  <h4 class="m-0 font-weight-bold text-primary"> <i class="fas fa-mobile-alt fa-sm fa-fw mr-2 text-gray-400"></i><?= $this->title ?>
     <span class="pull-right"> 
     <?= Html::a('<i class="fa fa-edit"></i>&nbsp;Update', ['update','id'=>$model->id], ['class' => 'btn btn-warning btn-rounded']) ?>
    <?= Html::a('<i class="fa fa-mobile-alt"></i>&nbsp;View Academic Activities ', ['index'], ['class' => 'btn btn-info btn-rounded']) ?>
 </span>
  </h4>
	</div>
<div class="card-body">
 <div class="row">   
 <div class="col-lg-12">
 	 <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
             'title',
            'description',
            'background'         
        ],
    ]) ?>

</div>

</div>

</div>


</div>
</section>