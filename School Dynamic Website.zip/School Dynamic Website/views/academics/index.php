<?php

use yii\helpers\Html;
use yii\grid\GridView;

$this->title = 'Academics Activities';
?>
<section id="services" class="services">
      <div class="container-fluid">
<div class="card shadow mb-4">
    <div class="card-header py-3">
      <h4 class="m-0 font-weight-bold text-primary"> <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i><?= $this->title ?> 
      <span class="pull-right"> 
    <?= Html::a('<i class="fa fa-plus"></i>&nbsp;Add Academics Activities', ['create'], ['class' => 'btn btn-success btn-rounded']) ?>   
</span>
</h4>
    </div>
    <div class="card-body">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $model,
        'tableOptions'=>['class'=>'table dataTable table-bordered table-striped table-hover table-condensed'],
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'], 
            'title',
            'description',
            'background',          
             [
                'class' => 'yii\grid\ActionColumn',
                'template' => '<div style="text-align:center;">{view}</div>',
                'buttons' => [
                    'view' => function ($url, $dataProvider) {
                        return Html::a('<i class="fa fa-eye"></i> View',['view', 'id' =>$dataProvider['id']],['class'=>'btn btn-primary']);
                },
                ],
             ],
            
        ],
    ]); ?>

</div>
</div>
</div>
</section>