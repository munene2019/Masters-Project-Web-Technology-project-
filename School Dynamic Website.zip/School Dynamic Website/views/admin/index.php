<?php
use yii\bootstrap4\Html;
/* @var $this yii\web\View */
?>
<section id="services" class="services">
      <div class="container-fluid">

      <div class="section-title">
      <h1><?= Html::encode($this->title) ?></h1>
      <p>Admin Dashboard:</p>
   <li>  <a href="<?= Yii::$app->urlManager->createAbsoluteUrl(['/corousel/index']) ?>">Corousel Items</a></li>
   <li> <a href="<?= Yii::$app->urlManager->createAbsoluteUrl(['/academics/index']) ?>">Academics Items</a></li>
   <li> <a href="<?= Yii::$app->urlManager->createAbsoluteUrl(['/programmes/index']) ?>">Programmes</a></li>
   <li> <a href="<?= Yii::$app->urlManager->createAbsoluteUrl(['/departments/index']) ?>">Departments</a></li>
   <li> <a href="<?= Yii::$app->urlManager->createAbsoluteUrl(['/courses/index']) ?>">Courses</a></li>

</p>
</div>
</div>
</section>
