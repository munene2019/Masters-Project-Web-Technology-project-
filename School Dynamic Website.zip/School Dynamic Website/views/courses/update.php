<?php

use yii\bootstrap4\ActiveForm;
use yii\bootstrap4\Html;
use app\models\Programmes;
use app\models\Departments;
use yii\helpers\ArrayHelper;
$program = ArrayHelper::map(Programmes::find()->all(),'id', 'name');
$depart = ArrayHelper::map(Departments::find()->all(),'id', 'name');
$this->title = 'Course';

?>
<section id="services" class="services">
      <div class="container-fluid">
     
<!-- Basic Card Example -->
<div class="card shadow mb-4">
	<div class="card-header py-3">
	  <h4 class="m-0 font-weight-bold text-primary"> <i class="fas fa-plus fa-sm fa-fw mr-2 text-gray-400"></i><?= $this->title ?>
	  <span class="pull-right"> 
    <?= Html::a('<i class="fa fa-mobile-alt"></i>&nbsp;View Courses', ['index'], ['class' => 'btn btn-info btn-rounded']) ?>
 </span></h4>
	</div>
	<div class="card-body">
	<h6>General Information (* Indicates required fields)</h6>
	<?php $form = ActiveForm::begin(['id' => 'create-procode-form', 'options' => ['enctype' => 'multipart/form-data'],]); ?>
<hr>

	<div class="row">
		<div class="col-lg-4 required">
			<?= $form->field($model, 'name')->textInput(['class'=>'form-control','type' => 'text','required'=>true,]); ?>
	    </div>
	</div>

    <div class="row">
		<div class="col-lg-4 required">
        <?= $form->field($model, 'programId')->dropDownList($program) ?>		
	    </div>
	</div>   

    <div class="row">
		<div class="col-lg-4 required">
        <?= $form->field($model, 'departId')->dropDownList($depart) ?>		
	    </div>
	</div>
    <div class="row">
		<div class="col-lg-4 required">
			<?= $form->field($model, 'requirement')->textInput(['class'=>'form-control','type' => 'text','required'=>true,]); ?>
	    </div>
	</div>
	
	<hr>
	<div class="row"> 
		<div class="col-lg-12">
			<?= Html::submitButton('Save &nbsp;<i class="fa fa-save"></i>', ['class' => 'btn btn-primary btn-rounded pull-right']) ?>
	    </div>
	</div>
     <?php ActiveForm::end(); ?>

	</div>

	</div>	
</div>
<style>
    form div.required label.control-label:after {
  content:" * ";
  color:red;

}
</style>


      
</div>
</section>