<?php

/** @var yii\web\View $this */

$this->title = 'Services';
?>
<br><br>
    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container-fluid">

      <div class="section-title">
          <?php

          if(!empty($paymentMethods)){         
            foreach($paymentMethods as $method){?>
              <h2>Payment Methods</h2>
              <h3>Check our <span>Payment Methods</span></h3>
              <p>Our payment Methods for the fees are usually through <?= $method['paymentOption']?> .</p>
              <p>Paybill <?= $method['description']?></p>
              <p>Account Number <?= $method['AccountNo']?></p>
              <p></p><?php
            }
          }
      
           ?>
         
        </div>

        
              
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Services Section -->