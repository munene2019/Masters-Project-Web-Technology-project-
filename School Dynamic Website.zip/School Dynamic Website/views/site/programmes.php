<?php

/** @var yii\web\View $this */

$this->title = 'Services';
?>
<br><br>
    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container-fluid">

        <div class="section-title">
          <h2>Programmes</h2>
          <h3>We have two Departments <span>in our school</span></h3>         
          <?php
          if(!empty($departments)){         
            foreach($departments as $deparment){?>
           <p> <?=$deparment['name']?><p><?php
            
            }
          }
          ?>
                
          <p></p>
        </div>
        <div class="row">
        <?php
          if(!empty($departments)){         
            foreach($departments as $deparment){?>
         <div class="col-xl-5 col-lg-6 icon-boxes d-flex flex-column align-items-stretch justify-content-center py-5 px-lg-5">
            <h3> <?=$deparment['name']?></h3><?php
            if(!empty($programmes)){            
            foreach($programmes as $progamme){?>  <p><?=$progamme['name']?></p><?php
           $courseModel=$courses->getCourses($progamme['id'],$deparment['id']);  
              if(!empty($courseModel)){
                foreach($courseModel as $course){?>
  <div class="icon-box">
              <div class="icon"><i class="bx bx-fingerprint"></i></div>
              <h4 class="title"><a href=""> <?= $course['name']?> </a></h4>
              <h4 class="title"><a href="">Course Requirements </a></h4>
           <?= $course['requirement']?>
 </p>
</div><?php


                }
              }
              
              
              ?>
          
            
          



            
            <?php




            }
          }
          ?>
 
      

            

            <!-- <p>Postgraduate Programmes.</p>
<div class="icon-box">
  <div class="icon"><i class="bx bx-fingerprint"></i></div>
  <h4 class="title"><a href="">Masters Software Engineering </a></h4>
  <p class="description">The course is designed to address research problems encouraged in real life business and industrial settings.

  <h4 class="title"><a href="">Course Requirements </a></h4>
(a) Holders of a Bachelor Degree in Computer Science/Computer Technology/Information Technology, Mathematics and Computer Science, and electronic engineering of at least upper second class Honours of JKUAT.

(b) Holders of a Bachelor Degree in a related discipline: Engineering, Mathematics, Statistics and Physics of at least upper Second Class Honours and holds a Postgraduate Diploma in Computer Science of a minimum credit grade from an institution recognized by senate or an equivalent qualification the Senaten institution recognized by senate. </p>
</div>

<div class="icon-box">
  <div class="icon"><i class="bx bx-gift"></i></div>
  <h4 class="title"><a href="">Masters Computer Systems</a></h4>
  <p class="description">The course is designed to address the needs of professional s with current and relevant technological skills in design, implementation and management of Information systems.</p>
  <h4 class="title"><a href="">Course Requirements </a></h4>
  i) Holders of a Bachelors Degree with Upper Second Honours.

ii) Holders of a Bachelors Degree of at least Lower Second Class Honours from a recognized University and relevant working experience of at least three(3) years.

iii) Holders of a Bachelor Degree with a pass and relevant working experience of at least five years. </p>
</div>

<div class="icon-box">
  <div class="icon"><i class="bx bx-atom"></i></div>
  <h4 class="title"><a href="">Masters Artificial Intelligence</a></h4>
  <p class="description">The course is designed to meet the increasing demand for smart ICT applications for addressing the challenges facing the modern society.</p>
  <h4 class="title"><a href="">Course Requirements </a></h4>
  i) Holders of a Bachelors Degree in Computing/Computer Science/Information Technology/Computer Technology/Computer Engineering or related field of at least Upper Second Honours from recognized university.

ii) Holders of a Bachelors Degree Computing/Computer Science/Information Technology/Computer Technology/Computer Engineering or related field of Lower Second Class Honours from recognized university with at least three (3) years working experience. </p>
</div> -->
</div><?php
            
            }
          }
          ?>
     

</div>
              
            </div>
           
         
           

      </div>
    </section><!-- End Services Section -->