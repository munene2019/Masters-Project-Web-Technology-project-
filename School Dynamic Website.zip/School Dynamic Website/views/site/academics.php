<?php

/** @var yii\web\View $this */

$this->title = 'Services';
?>
<br><br>
    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container-fluid">

        <div class="section-title">
          <h2>Academics</h2>
          <h3>Check our <span>Academics</span></h3>
          <p>We have various activities that our students are engaged in that contribute towards growth in their skills .</p>
        </div>

        <div class="row justify-content-center">
          <div class="col-xl-10">
            <div class="row">
              <?php

            if(!empty($academicsItems)){
              foreach($academicsItems as $item){?>
                <div class="col-lg-4 col-md-6 icon-box">
                <div class="icon"><i class="ri-pie-chart-line"></i></div>
                <h4 class="title"><a href=""><?= $item['title'] ?></a></h4>
                <p class="description"><?= $item['description'] ?></p>
              </div><?php
              }
            }
            ?>
            
              <!-- <div class="col-lg-4 col-md-6 icon-box">
                <div class="icon"><i class="ri-stack-line"></i></div>
                <h4 class="title"><a href="">Microsoft  Training and Cerifications</a></h4>
                <p class="description">Our school has a collaboration with Microsoft through the Microsoft ceritification programmers.Students are required to enroll on the various programmes and on successful completion they are issue with certificates</p>
                <p class="description">Our school also the workshop which revolves around the microsoft products annually.Students are enlightened on the contribution microsoft is making across the world through their powerful products.Cloud computing is one of the area which students are really brought the understanding and its operations.Azure which is the clould platform that Microsoft has developed is one of the major milestone Microst has made in the technology world and has a freat impact in businesses</p>
            
              </div>
              <div class="col-lg-4 col-md-6 icon-box">
                <div class="icon"><i class="ri-markup-line"></i></div>
                <h4 class="title"><a href="">CISCO Certifications</h4>
                <p class="description">Our school has a collaboration with CISCO for students to undertake the CCNA certifications.CISCO majorly focus on the networking aspect of the technology.The programmes broaden the skills for the students who are passionate about Networking field which also plays a very key role in the tecnology through the connection of devices and computers </p>
              </div> -->
              
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Services Section -->