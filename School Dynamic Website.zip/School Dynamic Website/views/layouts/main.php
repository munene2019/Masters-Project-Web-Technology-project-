<?php

/** @var yii\web\View $this */
/** @var string $content */

use app\assets\AppAsset;
use app\widgets\Alert;
use yii\bootstrap4\Breadcrumbs;
use yii\bootstrap4\Html;
use yii\bootstrap4\Nav;
use yii\bootstrap4\NavBar;

AppAsset::register($this);

?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>" >

<head>
<meta charset="<?= Yii::$app->charset ?>">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="description">
  <meta content="" name="keywords">
  <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">


 
  


  <!-- =======================================================
  * Template Name: Hidayah - v4.7.0
  * Template URL: https://bootstrapmade.com/hidayah-free-simple-html-template-for-corporate/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
<?php $this->beginBody() ?>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top header-inner-pages">
    <div class="container d-flex align-items-center justify-content-between">

      <h class="logo"><a href="index.html">JKUAT School CS & IT</a></h>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
  <li><i class="bx bx-chevron-right"></i> <a href="<?= Yii::$app->urlManager->createAbsoluteUrl(['/site/index']) ?>">Home</a></li>
                  <li><i class="bx bx-chevron-right"></i> <a href="<?= Yii::$app->urlManager->createAbsoluteUrl(['/site/academics']) ?>">Academics</a></li>
                  <li><i class="bx bx-chevron-right"></i>  <a href="<?= Yii::$app->urlManager->createAbsoluteUrl(['/site/payments']) ?>">Payment Methods</a></li>
                  <li><i class="bx bx-chevron-right"></i>  <a href="<?= Yii::$app->urlManager->createAbsoluteUrl(['/site/programmes']) ?>">Programmes</a></li>
                  <li><i class="bx bx-chevron-right"></i> <a href="<?= Yii::$app->urlManager->createAbsoluteUrl(['/site/login']) ?>">Login</a></li>
                  <li><i class="bx bx-chevron-right"></i>  <a href="<?= Yii::$app->urlManager->createAbsoluteUrl(['/site/staff']) ?>">Staff</a></li>
                  <li><i class="bx bx-chevron-right"></i> <a href="#">Apply Now</a></li>
        
          <!-- <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#services">Services</a></li>
          <li><a class="nav-link  scrollto" href="#portfolio">Portfolio</a></li>
          <li><a class="nav-link scrollto" href="#team">Team</a></li>
          <li class="dropdown"><a href="#"><span>Drop Down</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="#">Drop Down 1</a></li>
              <li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>
              <li><a href="#">Drop Down 2</a></li>
              <li><a href="#">Drop Down 3</a></li>
              <li><a href="#">Drop Down 4</a></li>
            </ul> -->
          </li>
          <!-- <li><a class="nav-link scrollto" href="#contact">Contact</a></li> -->
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
 
        <?= Alert::widget() ?>
        <?= $content ?>
  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-newsletter">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <h4>Our Newsletter</h4>
            <p>You are welcome to be part of us</p>
          </div>
          <div class="col-lg-6">
           
          </div>
        </div>
      </div>
    </div>

    <div class="footer-top">
      <div class="container-fluid">
        <div class="row justify-content-center">
          <div class="col-xl-10">
            <div class="row">

              <div class="col-lg-3 col-md-6 footer-links">
                <h4>Useful Links</h4>
                <ul>
                  <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
                  <li><i class="bx bx-chevron-right"></i> <a href="#">Academics</a></li>
                  <li><i class="bx bx-chevron-right"></i> <a href="#">Payment Methods</a></li>
                  <li><i class="bx bx-chevron-right"></i> <a href="#">Programmes</a></li>
                  <li><i class="bx bx-chevron-right"></i> <a href="#">Login</a></li>
                  <li><i class="bx bx-chevron-right"></i> <a href="#">Staff</a></li>
                  <li><i class="bx bx-chevron-right"></i> <a href="#">Apply Now</a></li>
                </ul>
              </div>

           

              <div class="col-lg-3 col-md-6 footer-contact">
                <h4>Contact Us</h4>
                <p>
                 JKUAT Main Campus <br>
                  Nairobi,535022<br>
                  Kenya <br><br>
                  <strong>Phone:</strong> 25471736699<br>
                  <strong>Email:</strong> info@jkuat.ac.ke<br>
                </p>

              </div>

            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>JKUAT</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/hidayah-free-simple-html-template-for-corporate/ -->
        Designed by <a href="https://bootstrapmade.com/">KenyaWeb Technologies</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

 <?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>

