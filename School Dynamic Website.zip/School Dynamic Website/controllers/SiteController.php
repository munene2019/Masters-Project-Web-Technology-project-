<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use app\models\CarouselItems;
use app\models\Academics;
use app\models\Paymentmethods;
use app\models\Programmes;
use app\models\Departments;
use app\models\Course;




class SiteController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionAcademics()
    {
        $model=new Academics();
        $academicsItems=$model->getAcademicsItems();
        return $this->render('academics',['academicsItems'=>$academicsItems]);
    }
    public function actionPaymentMethods()
    {
        $model=new Paymentmethods();
      
        $paymentMethods=$model->getPaymentMethods();
        print_r($paymentMethods);exit;
  
        return $this->render('paymentMethods',['paymentMethods'=>$paymentMethods]);
    }
    public function actionIndex()
    {
        $model=new CarouselItems();
        $carouselItems=$model->getCarouselItems();
        return $this->render('index',['carouselItems'=>$carouselItems]);
       
    }
    public function actionPayments()
    {
        $model=new Paymentmethods();
      
        $paymentMethods=$model->getPaymentMethods();       
  
        return $this->render('payments',['paymentMethods'=>$paymentMethods]);
    }
       

    public function actionProgrammes()
    {
          $courseModel=new Course();
        $model=new Programmes();
        $modelDepartment=new Departments();
        $departments=$modelDepartment->getDepartments(); 
        $programmes=$model->getProgrammes();  
      
  
        return $this->render('programmes',['programmes'=>$programmes,'departments'=>$departments,'courses'=>$courseModel]);
      
    }
    public function actionStaff()
    {
        return $this->render('staff');
    }
    /**
     * Login action.
     *
     * @return Response|string
     */
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->redirect(Yii::$app->urlManager->createAbsoluteUrl(['/admin/index']));
          
        }

        $model->password = '';
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    /**
     * Logout action.
     *
     * @return Response
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    /**
     * Displays contact page.
     *
     * @return Response|string
     */
    public function actionContact()
    {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('contact', [
            'model' => $model,
        ]);
    }

    /**
     * Displays about page.
     *
     * @return string
     */
    public function actionAbout()
    {
        return $this->render('about');
    }
}
