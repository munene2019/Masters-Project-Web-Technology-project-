<?php

namespace app\controllers;
use Yii;
use app\models\Academics;

class AcademicsController extends \yii\web\Controller
{
    public function actionIndex()
    {
        $model=new Academics();
        $dataProvider=$model->search(Yii::$app->request->queryParams);
        return $this->render('index',['dataProvider'=>$dataProvider,'model'=>$model]);
    }
    public function actionView($id)
    {      
        $model = $this->findModel($id);  
        return $this->render('view',['model' => $model]);
    } 
    public function actionUpdate($id)
    {       
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post())) {
            if($model->save()){             
                Yii::$app->session->setFlash('success',"<i class='fa fa-check'></i> Academic activity  <i>$model->title</i> details updated successfully");
                  return  $this->redirect(Yii::$app->request->referrer);
            }
            else{
             foreach ($model->errors as $key => $value) {
              Yii::$app->session->setFlash('error',"<i class='fa fa-remove'></i> $value[0]");
             }
            }
            
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }
    public function actionCreate(){

        $model = new Academics();
    
         if($model->load(Yii::$app->request->post())===true) {
           
          $model->attributes = Yii::$app->request->post();         
    
          if($model->validate()){        
               
            if($model->save()){             
                Yii::$app->session->setFlash('success',"New Academic activity  <i>$model->title</i> details saved successfully.");
                return  $this->redirect(Yii::$app->request->referrer);
            }
            else {
              foreach ($model->errors as $key => $value) {
              Yii::$app->session->setFlash('error',"<i class='fa fa-remove'></i> $value[0]");
             }
            }
          }
          else{
             foreach ($model->errors as $key => $value) {
              Yii::$app->session->setFlash('error',"<i class='fa fa-remove'></i> $value[0]");
             }
          
          }
               
        }
        return $this->render('create', [
                'model' => $model,
            ]);
    }
    protected function findModel($id)
{
    if (($model = Academics::findOne(['id'=>$id])) !== null) {
        return $model;
    } 
    else {
        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
}

