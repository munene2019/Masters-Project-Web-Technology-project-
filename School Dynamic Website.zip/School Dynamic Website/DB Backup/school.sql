-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2022 at 11:17 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `academics`
--

CREATE TABLE `academics` (
  `id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `background` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `academics`
--

INSERT INTO `academics` (`id`, `title`, `description`, `background`) VALUES
(1, 'Building capacity for cyber security', 'Our school of usually hold one cyber security workshop among the IT students.In the workshop,students are taken through various training that cut across the security in the systems.Students are also emphasized on the crucial role that the security plays in the software systems.This ensures that students are fully aware and taught on the cyber security field', ''),
(2, 'Microsoft  Training and Cerifications', 'Our school has a collaboration with Microsoft through the Microsoft ceritification programmers.Students are required to enroll on the various programmes and on successful completion they are issue with certificates.Our school also the workshop which revolves around the microsoft products annually.Students are enlightened on the contribution microsoft is making across the world through their powerful products.Cloud computing is one of the area which students are really brought the understanding and its operations.Azure which is the clould platform that Microsoft has developed is one of the major milestone Microst has made in the technology world and has a freat impact in businesses', ''),
(3, 'CISCO Certifications2022', 'Our school has a collaboration with CISCO for students to undertake the CCNA certifications.CISCO majorly focus on the networking aspect of the technology.The programmes broaden the skills for the students who are passionate about Networking field which also plays a very key role in the tecnology through the connection of devices and computers', 'test'),
(4, 'Cloud Computing', 'Azures', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `carousel_items`
--

CREATE TABLE `carousel_items` (
  `id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `background` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `carousel_items`
--

INSERT INTO `carousel_items` (`id`, `title`, `description`, `background`) VALUES
(1, 'Welcome to <span>JKUAT  School of Computing and Information Technology', 'Our school is committed to providing highly skilled and knowledgeable learners in the IT field.', 'slide-1.jpg'),
(2, 'SCIT is  the place to be', 'We are determined  to providing highly skilled graduates in the technology world', 'slide-2.jpg'),
(4, 'welcome', 'SCIT is at your service', 'slide-2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `programId` int(11) NOT NULL,
  `departId` int(11) NOT NULL,
  `requirement` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `name`, `programId`, `departId`, `requirement`) VALUES
(1, 'Computer Technology', 3, 1, 'K.C.S.E; Aggregate C+ and average grade C+ in one of the following subject combinations: Mathematics, Physics and Chemistry · Diploma in Computer Technology, Computer Science, Information Technology, or in any other relevant diploma with a credit pass from an Institution recognized by the Senate. Any other qualifications deemed by the Senate to be equivalent to the above.'),
(2, 'Business InformationTechnology', 3, 2, 'K.C.S.E; Aggregate C+ and average grade C+ in one of the following subject combinations: Mathematics, Physics and Chemistry · Diploma in Computer Technology, Computer Science, Information Technology, or in any other relevant diploma with a credit pass from an Institution recognized by the Senate. Any other qualifications deemed by the Senate to be equivalent to the above.'),
(3, 'Software Engineering', 4, 1, 'K.C.S.E; Aggregate C+ and average grade C+ in one of the following subject combinations: Mathematics, Physics and Chemistry · Diploma in Computer Technology, Computer Science, Information Technology, or in any other relevant diploma with a credit pass from an Institution recognized by the Senate. Any other qualifications deemed by the Senate to be equivalent to the above.'),
(4, 'Information Technology', 3, 2, 'K.C.S.E; Aggregate C+ and average grade C+ in one of the following subject combinations: Mathematics, Physics and Chemistry · Diploma in Computer Technology, Computer Science, Information Technology, or in any other relevant diploma with a credit pass from an Institution recognized by the Senate. Any other qualifications deemed by the Senate to be equivalent to the above.'),
(5, 'Artificial Intelligence', 4, 2, 'K.C.S.E; Aggregate C+ and average grade C+ in one of the following subject combinations: Mathematics, Physics and Chemistry · Diploma in Computer Technology, Computer Science, Information Technology, or in any other relevant diploma with a credit pass from an Institution recognized by the Senate. Any other qualifications deemed by the Senate to be equivalent to the above.'),
(6, 'ComputerScience', 3, 1, 'K.C.S.E; Aggregate C+ and average grade C+ in one of the following subject combinations: Mathematics, Physics and Chemistry · Diploma in Computer Technology, Computer Science, Information Technology, or in any other relevant diploma with a credit pass from an Institution recognized by the Senate. Any other qualifications deemed by the Senate to be equivalent to the above.'),
(7, 'test2', 3, 1, 'A');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`) VALUES
(1, 'Computing'),
(2, 'Information Technology'),
(3, 'HRI');

-- --------------------------------------------------------

--
-- Table structure for table `paymentmethods`
--

CREATE TABLE `paymentmethods` (
  `id` int(11) NOT NULL,
  `paymentOption` varchar(100) NOT NULL,
  `description` varchar(150) NOT NULL,
  `AccountNo` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `paymentmethods`
--

INSERT INTO `paymentmethods` (`id`, `paymentOption`, `description`, `AccountNo`) VALUES
(1, 'MPESA', '247247', '1520636383883');

-- --------------------------------------------------------

--
-- Table structure for table `programmes`
--

CREATE TABLE `programmes` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `programmes`
--

INSERT INTO `programmes` (`id`, `name`) VALUES
(3, 'Undergraduate'),
(4, 'Postgraduate'),
(5, 'Certificate'),
(6, 'Certificate'),
(7, 'Certificate1');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `authKey` varchar(100) NOT NULL,
  `accessToken` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `authKey`, `accessToken`) VALUES
(1, 'rogers', 'rogers', '4332EDSFDSASDA', 'DFFDFDDFFD');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academics`
--
ALTER TABLE `academics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `carousel_items`
--
ALTER TABLE `carousel_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_departments` (`departId`),
  ADD KEY `FK_programme` (`programId`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paymentmethods`
--
ALTER TABLE `paymentmethods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `programmes`
--
ALTER TABLE `programmes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academics`
--
ALTER TABLE `academics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `carousel_items`
--
ALTER TABLE `carousel_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `paymentmethods`
--
ALTER TABLE `paymentmethods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `programmes`
--
ALTER TABLE `programmes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `course`
--
ALTER TABLE `course`
  ADD CONSTRAINT `FK_programme` FOREIGN KEY (`programId`) REFERENCES `programmes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
