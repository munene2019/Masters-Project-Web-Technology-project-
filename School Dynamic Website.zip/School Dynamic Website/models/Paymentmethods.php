<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "paymentmethods".
 *
 * @property int $id
 * @property string $paymentOption
 * @property string $description
 * @property string $AccountNo
 */
class Paymentmethods extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'paymentmethods';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['paymentOption', 'description', 'AccountNo'], 'required'],
            [['paymentOption'], 'string', 'max' => 100],
            [['description', 'AccountNo'], 'string', 'max' => 150],
        ];
    }


    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'paymentOption' => 'Payment Option',
            'description' => 'Description',
            'AccountNo' => 'Account No',
        ];
    }
    public function search($params){
   
        $query = Paymentmethods::find();
       
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => ['pageSize' => 12],
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }
   
    $query->andFilterWhere(['like', 'paymentOption', $this->paymentOption])
           ->andFilterWhere(['like', 'paymentOption', $this->description])   
           ->andFilterWhere(['like', 'AccountNo', $this->AccountNo]);        
           
        return $dataProvider;
    }
    public function getPaymentMethods(){
        return  Paymentmethods::find()->all();
 
     }
}
