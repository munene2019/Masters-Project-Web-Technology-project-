<?php

namespace app\models;

use Yii;
use yii\data\ActiveDataProvider;

/**
 * This is the model class for table "course".
 *
 * @property int $id
 * @property string $name
 * @property int $programId
 * @property int $departId
 * @property string $requirement
 *
 * @property Programmes $program
 */
class Course extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'course';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            // [['name', 'programId', 'departId', 'requirement'], 'required'],
            [['programId', 'departId'], 'integer'],
            [['name'], 'string', 'max' => 50],
            [['requirement'], 'string', 'max' => 1000],
            [['programId'], 'exist', 'skipOnError' => true, 'targetClass' => Programmes::className(), 'targetAttribute' => ['programId' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'programId' => 'Program ID',
            'departId' => 'Depart ID',
            'requirement' => 'Requirement',
        ];
    }
    public function getProgramme(){
        return $this->hasOne(Programmes::className(), ['id' => 'programId']);
    }
    public function getDepartment(){
        return $this->hasOne(Departments::className(), ['id' => 'departId']);
    }
    public function search($params){
   
        $query = Course::find();
       
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => ['pageSize' => 12],
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }
   
    $query->andFilterWhere(['like', 'name', $this->name])
           ->andFilterWhere(['like', 'programId', $this->programId])
           ->andFilterWhere(['like', 'departId', $this->departId])
           ->andFilterWhere(['like', 'requirement', $this->requirement]);          
           
        return $dataProvider;
    }
    public function getCourses($programId,$departId){
        return   Course::find()->where(['programId'=>$programId,'departId'=>$departId])->all();
 
     }

    /**
     * Gets query for [[Program]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProgram()
    {
        return $this->hasOne(Programmes::className(), ['id' => 'programId']);
    }


}
