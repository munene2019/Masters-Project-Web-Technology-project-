<?php

namespace app\models;

use Yii;
use yii\data\ActiveDataProvider;

/**
 * This is the model class for table "academics".
 *
 * @property int $id
 * @property string $title
 * @property string $description
 * @property string $background
 */
class Academics extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'academics';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            // [['title', 'description', 'background'], 'required'],
            [['title'], 'string', 'max' => 150],
            [['description'], 'string', 'max' => 1000],
            [['background'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Title',
            'description' => 'Description',
            'background' => 'Background',
        ];
    }
    public function search($params){
   
        $query = Academics::find();
       
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => ['pageSize' => 12],
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }
   
    $query->andFilterWhere(['like', 'title', $this->title])
           ->andFilterWhere(['like', 'description', $this->description]);          
           
        return $dataProvider;
    }
    public function getAcademicsItems(){
        return   Academics::find()->all();
 
     }
}
