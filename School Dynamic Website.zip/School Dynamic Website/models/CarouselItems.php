<?php

namespace app\models;

use Yii;
use yii\data\ActiveDataProvider;
/**
 * This is the model class for table "carousel_items".
 *
 * @property int $id
 * @property string $title
 * @property string $description
 * @property string $background
 */
class CarouselItems extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'carousel_items';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            // [['title', 'description', 'background'], 'required'],
            [['title'], 'string', 'max' => 150],
            [['description'], 'string', 'max' => 1000],
            [['background'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Title',
            'description' => 'Description',
            'background' => 'Background',
        ];
    }
    public function search($params){
   
        $query = CarouselItems::find();
       
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => ['pageSize' => 12],
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }
   
    $query->andFilterWhere(['like', 'title', $this->title])
           ->andFilterWhere(['like', 'description', $this->description]);          
           
        return $dataProvider;
    }
    public function getCarouselItems(){
       return  CarouselItems::find()->all();

    }
}
